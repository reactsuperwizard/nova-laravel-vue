Nova.booting((Vue, router, store) => {
    Vue.component('newinput-range', require('./components/Filter'))
})
