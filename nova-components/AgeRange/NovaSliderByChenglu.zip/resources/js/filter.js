Nova.booting((Vue, router, store) => {
    Vue.component('age-range', require('./components/Filter'))
})
