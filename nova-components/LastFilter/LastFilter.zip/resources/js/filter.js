Nova.booting((Vue, router, store) => {
    Vue.component('last-filter', require('./components/Filter'))
})
